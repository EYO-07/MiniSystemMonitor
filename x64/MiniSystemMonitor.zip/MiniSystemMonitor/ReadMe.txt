--------------------------------------------------------------- Windows ----------------------------------------------------------------
Hi, I am oZumbiAnalitico an amateur programmer
... This program was made with Visual Studio Community and assisted by Grok A.I.
... it uses third party resources which I can't store here, so you need to find by yourself
1. OpenHardwareMonitorLib.dll ; Download the OpenHardwareMonitorLib and put the OpenHardwareMonitorLib.dll inside the executable folder.
2. Windows Media Player ; ... 

[ MiniSystemMonitor ] : Minimalist Translucent Gadget for Monitoring Resources 
1. CPU Load, Temperature
2. GPU Load, Temperature, Fan Speed
3. Ram Load
4. XXD Temperature
5. Detect .mp3 in directory or subdirectories to create a random music playlist
6. Display diferent colors based on critical stats (temperature, load).

Notes:
1. Need Administrator Privilege to access the hardware info. Right-click and select execute as administrator.
2. Full Conversation with Grok: https://x.com/i/grok/share/WdFH29Jam1pfj4pfv0b7z85n6 
3. Right-Click to access Windows Media Player context menu (controls de volume, play, pause, ...)
4. Tell me if you find any problem =D 
--------------------------------------------------------------- ........ ----------------------------------------------------------------